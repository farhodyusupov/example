# SmartPaperScan
this is an android project write in kotlin which detect paper or rectangle by opencv, you can take a picture and crop it
# Example
you can detect paper on desktop like this

## detecting previewing picture
<img src="https://github.com/KePeng1019/SmartPaperScan/raw/master/example/detect_preview_pic.jpeg" width="220">

## detecting picture take by camera
<img src="https://github.com/KePeng1019/SmartPaperScan/raw/master/example/detect_token_pic.jpeg" width="220">


# Addition
code is written in pure kotlin, hope this project will be helpful to you.
previous version only work well on device of 1080 * 1920 resolution ratio, this bug fixed in this version.

